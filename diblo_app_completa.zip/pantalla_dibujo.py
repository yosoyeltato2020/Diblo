# pantalla_dibujo.py
import os
import random
import datetime
import logging
from kivy.uix.screenmanager import Screen
from kivy.properties import ObjectProperty, StringProperty, ListProperty
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.graphics import Color, Line, Rectangle
from kivy.core.window import Window
from kivy.metrics import dp # Importar dp
from functools import partial # Para partial en los binds

from componentes import DrawingArea
import reconocimiento_offline
import pronunciador
import palabras
import locale_manager
import config

# Configuración del logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Formateador para convertir tuplas RGBA a string hexadecimal para Kivy
def rgb_to_hex(rgba_color):
    """Convierte un color RGBA (0-1) a formato hexadecimal de Kivy (RRGGBBAA)."""
    r = int(rgba_color[0] * 255)
    g = int(rgba_color[1] * 255)
    b = int(rgba_color[2] * 255)
    a = int(rgba_color[3] * 255)
    return f"{r:02x}{g:02x}{b:02x}{a:02x}"

class PantallaDibujo(Screen):
    drawing_area = ObjectProperty(None)
    lbl_palabra = ObjectProperty(None) # Si aún la usas para el markup de color
    lbl_palabra_base_text = ObjectProperty(None) # Para la etiqueta sin markup
    lbl_mensaje_voz = ObjectProperty(None)
    lbl_categoria_actual = ObjectProperty(None)
    spinner_categorias = ObjectProperty(None)
    btn_mic = ObjectProperty(None)
    current_color_idx = ListProperty([0]) # Usamos una lista para que sea mutable y se actualice en kv
    popup_mensaje = ObjectProperty(None) # Para el popup general

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.palabra_actual = ""
        self.idioma = locale_manager.locale_manager.get_current_lang() # Asegura que usas la instancia global
        self.is_listening = False
        self.recognition_thread = None
        self.hex_colors = [rgb_to_hex(c) for c in config.PALETA_COLORES] # Colores en hex para Kivy
        self.is_offline_mode = False # Se actualiza en `on_enter`
        self.color_buttons = [] # Lista para almacenar las referencias a los botones de color
        self.selected_border = None # Referencia al Line que dibuja el borde

        Clock.schedule_once(self._setup_widgets)

    def _setup_widgets(self, dt):
        """Asigna los objetos de Kivy al código Python y genera los botones de color."""
        self.drawing_area = self.ids.drawing_area
        self.lbl_palabra_base_text = self.ids.lbl_palabra_base_text

        # Si aún tienes lbl_palabra en KV para el markup, asigna también:
        # self.lbl_palabra = self.ids.lbl_palabra

        self.lbl_mensaje_voz = self.ids.lbl_mensaje_voz
        self.lbl_categoria_actual = self.ids.lbl_categoria_actual_id
        self.spinner_categorias = self.ids.spinner_categorias_id
        self.btn_mic = self.ids.btn_mic_id

        # === Configurar spinner de categorías ===
        self.spinner_categorias.values = palabras.get_all_categories()
        self.spinner_categorias.text = locale_manager.locale_manager.get_localized_text("all_categories")
        self.spinner_categorias.bind(text=self.on_spinner_category_selected)

        # === Generar botones de color dinámicamente ===
        color_grid = self.ids.color_buttons_grid
        if color_grid:
            color_grid.clear_widgets()

            for i, color_rgba in enumerate(config.PALETA_COLORES):
                btn_color = Button(
                    background_color=color_rgba,
                    size_hint=(None, None),
                    size=(dp(40), dp(40))
                )
                btn_color.color_index = i
                btn_color.bind(on_release=self.cambiar_color_lapiz)
                color_grid.add_widget(btn_color)
                self.color_buttons.append(btn_color)

            if self.color_buttons:
                if self.current_color_idx[0] >= len(self.color_buttons):
                    self.current_color_idx[0] = 0
                self.drawing_area.set_color(config.PALETA_COLORES[self.current_color_idx[0]])
                self.draw_selected_color_border()

        locale_manager.locale_manager.bind(on_lang_change=self.update_ui_text)
        self.update_ui_text()

    def draw_selected_color_border(self):
        """Dibuja un borde alrededor del botón de color seleccionado."""
        if not self.color_buttons or not hasattr(self.ids, 'color_buttons_grid'):
            return

        color_grid = self.ids.color_buttons_grid
        with color_grid.canvas.after:
            color_grid.canvas.after.clear()
            self.selected_border = None

        selected_index = self.current_color_idx[0]
        if 0 <= selected_index < len(self.color_buttons):
            selected_btn = self.color_buttons[selected_index]
            with color_grid.canvas.after:
                Color(0, 0, 0, 1) # Borde negro
                self.selected_border = Line(
                    width=dp(2),
                    rectangle=(
                        selected_btn.x - dp(2), selected_btn.y - dp(2),
                        selected_btn.width + dp(4), selected_btn.height + dp(4)
                    )
                )

    def update_ui_text(self, *args):
        if self.ids:
            if 'btn_nueva_palabra' in self.ids:
                self.ids.btn_nueva_palabra.text = locale_manager.locale_manager.get_localized_text("new_word")
            if 'btn_borrar' in self.ids:
                self.ids.btn_borrar.text = locale_manager.locale_manager.get_localized_text("clear_canvas")
            if 'btn_guardar' in self.ids:
                self.ids.btn_guardar.text = locale_manager.locale_manager.get_localized_text("save_drawing")
            if 'btn_pronunciar' in self.ids:
                self.ids.btn_pronunciar.text = locale_manager.locale_manager.get_localized_text("pronounce")
            if 'btn_mic_id' in self.ids:
                self.ids.btn_mic_id.text = locale_manager.locale_manager.get_localized_text("listen")
            if 'btn_menu_principal' in self.ids:
                self.ids.btn_menu_principal.text = locale_manager.locale_manager.get_localized_text("main_menu")
            if 'lbl_categoria_actual_id' in self.ids:
                self.ids.lbl_categoria_actual_id.text = locale_manager.locale_manager.get_localized_text("category")
            
            if hasattr(self, 'spinner_categorias') and (self.spinner_categorias.text == self.palabra_actual or self.spinner_categorias.text not in palabras.get_all_categories()):
                self.spinner_categorias.text = locale_manager.locale_manager.get_localized_text("all_categories")

        self.idioma = locale_manager.locale_manager.get_current_lang()

    def on_enter(self, *args):
        logger.info("Entrando a PantallaDibujo.")
        self.reiniciar_juego()
        self.is_offline_mode = reconocimiento_offline.load_vosk_model_if_needed(
            self.show_offline_model_error
        )
        self.spinner_categorias.values = palabras.get_all_categories()
        self.spinner_categorias.text = locale_manager.locale_manager.get_localized_text("all_categories")


    def on_spinner_category_selected(self, spinner, text):
        if text == locale_manager.locale_manager.get_localized_text("all_categories"):
            palabras.set_current_category(None)
        else:
            palabras.set_current_category(text)
        self.generar_nueva_palabra()

    def generar_nueva_palabra(self):
        self.palabra_actual = palabras.get_random_word(self.idioma)
        if not self.palabra_actual:
            logger.error("No se pudo obtener una palabra. Revisa palabras.json.")
            self.show_popup(
                locale_manager.locale_manager.get_localized_text("error_title"),
                locale_manager.locale_manager.get_localized_text("no_words_error"),
                "error"
            )
            return

        logger.info(f"Nueva palabra generada: {self.palabra_actual}")
        self.lbl_palabra_base_text.text = self.palabra_actual
        self.update_palabra_label_color()
        self.drawing_area.clear_canvas()
        self.lbl_mensaje_voz.text = ""
        self.btn_mic.disabled = False

    def update_palabra_label_color(self):
        base_text = self.lbl_palabra_base_text.text
        if base_text:
            color_hex = self.hex_colors[self.current_color_idx[0]]
            self.lbl_palabra_base_text.text = f"[color={color_hex}]{base_text}[/color]"
        else:
            self.lbl_palabra_base_text.text = ""


    def reiniciar_juego(self):
        self.generar_nueva_palabra()
        self.drawing_area.clear_canvas()
        self.lbl_mensaje_voz.text = ""
        self.btn_mic.disabled = False

    def cambiar_color_lapiz(self, instance):
        self.current_color_idx[0] = instance.color_index
        self.drawing_area.set_color(config.PALETA_COLORES[self.current_color_idx[0]])
        logger.info(f"Color del lápiz cambiado a índice: {self.current_color_idx[0]}")
        self.update_palabra_label_color()
        self.draw_selected_color_border()


    def borrar_dibujo(self):
        self.show_confirmation_popup(
            locale_manager.locale_manager.get_localized_text("confirm_clear_title"),
            locale_manager.locale_manager.get_localized_text("confirm_clear_message"),
            self.drawing_area.clear_canvas
        )

    def guardar_dibujo(self):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"dibujo_{self.palabra_actual.lower().replace(' ', '_')}_{timestamp}.png"
        save_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dibujos")
        os.makedirs(save_dir, exist_ok=True)
        filepath = os.path.join(save_dir, filename)

        popup_content = BoxLayout(orientation='vertical', spacing=config.ESPACIADO_POPUP)
        img_preview = Image(source=self.drawing_area.export_to_png(filepath, crop=False), size_hint_y=0.8)
        lbl_info = Label(text=locale_manager.locale_manager.get_localized_text("drawing_saved_to").format(path=filepath),
                         halign='center', valign='middle', size_hint_y=0.2, text_size=(self.width*config.ANCHO_POPUP_GUARDAR_DIBUJO*0.9, None))
        lbl_info.bind(size=lbl_info.setter('text_size'))

        popup_content.add_widget(img_preview)
        popup_content.add_widget(lbl_info)

        popup = Popup(
            title=locale_manager.locale_manager.get_localized_text("drawing_saved_title"),
            content=popup_content,
            size_hint=(config.ANCHO_POPUP_GUARDAR_DIBUJO, config.ALTO_POPUP_GUARDAR_DIBUJO),
            auto_dismiss=True
        )
        popup.open()
        logger.info(f"Dibujo guardado en: {filepath}")


    def pronunciar_palabra(self):
        pronunciador.speak(self.palabra_actual, self.idioma)

    def iniciar_reconocimiento_voz(self):
        if self.is_listening:
            logger.info("Ya está escuchando, ignorando la solicitud de inicio.")
            return

        self.is_listening = True
        self.btn_mic.disabled = True
        self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("listening_message")
        self.lbl_mensaje_voz.color = config.COLOR_ESCUCHANDO
        Clock.schedule_interval(self.blink_text_color, 0.5)

        logger.info("Iniciando reconocimiento de voz...")
        self.recognition_thread = reconocimiento_offline.start_recognition_thread(
            self.palabra_actual,
            self.idioma,
            self.on_recognition_result,
            self.on_recognition_error,
            self.is_offline_mode
        )

    def on_recognition_result(self, recognized_text):
        self.stop_listening_ui()
        logger.info(f"Texto reconocido: {recognized_text}")

        if recognized_text.lower() == self.palabra_actual.lower():
            self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("correct_pronunciation")
            self.lbl_mensaje_voz.color = config.COLOR_CORRECTO
            Clock.schedule_once(lambda dt: self.generar_nueva_palabra(), 2)
        else:
            self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("incorrect_pronunciation").format(word=self.palabra_actual)
            self.lbl_mensaje_voz.color = config.COLOR_ERROR
            self.btn_mic.disabled = False

    def on_recognition_error(self, error_type, message):
        self.stop_listening_ui()
        logger.error(f"Error de reconocimiento: {error_type} - {message}")

        if error_type == "no_mic":
            self.show_popup_problema(
                locale_manager.locale_manager.get_localized_text("no_mic_title"),
                locale_manager.locale_manager.get_localized_text("no_mic_message"),
                "error"
            )
        elif error_type == "no_internet" and not self.is_offline_mode:
             self.show_popup_problema(
                locale_manager.locale_manager.get_localized_text("no_internet_title"),
                locale_manager.locale_manager.get_localized_text("no_internet_message"),
                "warning"
            )
        elif error_type == "unknown_value":
            self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("speech_unintelligible")
            self.lbl_mensaje_voz.color = config.COLOR_ERROR
        elif error_type == "request_error":
            self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("recognition_service_error")
            self.lbl_mensaje_voz.color = config.COLOR_ERROR
        elif error_type == "vosk_not_loaded":
            self.show_offline_model_error(message)
        else:
            self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("general_recognition_error")
            self.lbl_mensaje_voz.color = config.COLOR_ERROR

        self.btn_mic.disabled = False

    def stop_listening_ui(self):
        self.is_listening = False
        Clock.unschedule(self.blink_text_color)

    def blink_text_color(self, dt):
        if self.lbl_mensaje_voz.color == config.COLOR_ESCUCHANDO:
            self.lbl_mensaje_voz.color = (0.5, 0.5, 0.5, 1)
        else:
            self.lbl_mensaje_voz.color = config.COLOR_ESCUCHANDO

    def show_popup(self, title, message, type="info", callback=None):
        content = BoxLayout(orientation='vertical', spacing=config.ESPACIADO_POPUP)
        content.add_widget(Label(text=message, halign='center', valign='middle',
                                 text_size=(self.width*0.75, None)))

        btn_ok = Button(text=locale_manager.locale_manager.get_localized_text("ok"),
                        size_hint_y=None, height=config.ALTURA_BOTON_POPUP,
                        background_normal='', background_color=config.COLOR_BOTON_PRIMARIO)
        content.add_widget(btn_ok)

        self.popup_mensaje = Popup(title=title, content=content,
                                   size_hint=(config.ANCHO_POPUP_CONFIRMACION, config.ALTO_POPUP_CONFIRMACION),
                                   auto_dismiss=False)
        btn_ok.bind(on_release=self.popup_mensaje.dismiss)
        if callback:
            btn_ok.bind(on_release=callback)
        self.popup_mensaje.open()

    def show_confirmation_popup(self, title, message, on_yes_callback):
        content = BoxLayout(orientation='vertical', spacing=config.ESPACIADO_POPUP)
        content.add_widget(Label(text=message, halign='center', valign='middle',
                                 text_size=(self.width*0.75, None)))

        button_box = BoxLayout(orientation='horizontal', spacing=config.ESPACIADO_POPUP, size_hint_y=None, height=config.ALTURA_BOTON_POPUP)

        btn_yes = Button(text=locale_manager.locale_manager.get_localized_text("yes"),
                         background_normal='', background_color=config.COLOR_BOTON_ACEPTAR)
        btn_no = Button(text=locale_manager.locale_manager.get_localized_text("no"),
                        background_normal='', background_color=config.COLOR_BOTON_CANCELAR)

        button_box.add_widget(btn_yes)
        button_box.add_widget(btn_no)
        content.add_widget(button_box)

        popup = Popup(title=title, content=content,
                      size_hint=(config.ANCHO_POPUP_CONFIRMACION, config.ALTO_POPUP_CONFIRMACION),
                      auto_dismiss=False)

        btn_yes.bind(on_release=lambda x: (popup.dismiss(), on_yes_callback()))
        btn_no.bind(on_release=popup.dismiss)
        popup.open()

    def show_popup_problema(self, title, message, type="error"):
        content = BoxLayout(orientation='vertical', spacing=config.ESPACIADO_POPUP)
        content.add_widget(Label(text=message, halign='center', valign='middle',
                                 text_size=(self.width*0.75, None)))
        btn_ok = Button(text=locale_manager.locale_manager.get_localized_text("ok"),
                        size_hint_y=None, height=config.ALTURA_BOTON_POPUP,
                        background_normal='', background_color=config.COLOR_BOTON_PRIMARIO)
        content.add_widget(btn_ok)

        popup = Popup(title=title, content=content,
                      size_hint=(config.ANCHO_POPUP_PROBLEMA, config.ALTO_POPUP_PROBLEMA_PEQ if type == "warning" else config.ALTO_POPUP_PROBLEMA),
                      auto_dismiss=False)
        btn_ok.bind(on_release=popup.dismiss)
        popup.open()

    def show_offline_model_error(self, message):
        self.show_popup_problema(
            locale_manager.locale_manager.get_localized_text("vosk_model_error_title"),
            message,
            "error"
        )
        self.is_offline_mode = False
        self.btn_mic.disabled = False
        self.lbl_mensaje_voz.text = locale_manager.locale_manager.get_localized_text("offline_mode_unavailable")
        self.lbl_mensaje_voz.color = config.COLOR_ERROR

    def go_to_main_menu(self):
        self.manager.current = 'welcome_screen'