# main.py

import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.properties import ObjectProperty, StringProperty
from kivy.clock import Clock
import logging

# Importaciones de tus módulos de backend
import locale_manager
import config
import pronunciador
import reconocimiento_offline
import cache_manager

from pantalla_dibujo import PantallaDibujo

# Configuración del logger para main.py
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

class WelcomeScreen(Screen):
    welcome_text = StringProperty("")
    lang_label_text = StringProperty("")
    start_button_text = StringProperty("")
    selected_language_name = StringProperty("Español")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Clock.schedule_once(lambda dt: self._post_init_binding(), 0)

    def _post_init_binding(self, *args):
        locale_manager.locale_manager.bind(on_lang_change=self.update_ui_text)
        self.update_ui_text()

    def update_ui_text(self, *args):
        self.welcome_text = locale_manager.locale_manager.get_localized_text("welcome_title")
        self.lang_label_text = locale_manager.locale_manager.get_localized_text("language_selection_label")
        self.start_button_text = locale_manager.locale_manager.get_localized_text("start_button")

        if self.ids and 'lang_spinner' in self.ids:
            current_lang_code = locale_manager.locale.get_current_lang()
            if current_lang_code == 'es':
                self.ids.lang_spinner.text = "Español"
            elif current_lang_code == 'en':
                self.ids.lang_spinner.text = "English"

    def on_lang_spinner_text(self, text):
        logger.info(f"Idioma seleccionado en spinner: {text}")
        if text == 'Español':
            locale_manager.locale_manager.set_language('es')
        elif text == 'English':
            locale_manager.locale_manager.set_language('en')
        self.selected_language_name = text

class DibloApp(App):
    sm = ObjectProperty(None) # Referencia al ScreenManager

    def build(self):
        self.title = "Diblo"
        # Kivy asociará automáticamente el root usando diblo.kv y <DibloApp>
        # NO accedemos aquí a self.root, ni retornamos nada manual.
        pass

    def on_start(self):
        logger.info("Aplicación Diblo iniciada y bucle principal en ejecución.")

        # Ahora sí podemos acceder a self.root y a sus ids
        if not hasattr(self.root, 'ids') or 'screen_manager' not in self.root.ids:
            logger.critical("ERROR CRÍTICO: El ScreenManager con id 'screen_manager' no se encontró en self.root.ids.")
            logger.critical(f"IDs disponibles en self.root: {self.root.ids.keys() if hasattr(self.root, 'ids') and self.root.ids else 'Ninguno'}")
            logger.critical(f"Tipo de self.root: {type(self.root)}")
        else:
            self.sm = self.root.ids.screen_manager
            # Programamos el salto a la pantalla de bienvenida tras 3 segundos
            Clock.schedule_once(self.show_main_screen, 3)

    def show_main_screen(self, dt):
        logger.info("Carga inicial completa, cambiando a la pantalla de bienvenida.")
        self.sm.current = 'welcome_screen'

    def on_stop(self):
        logger.info("Aplicación Diblo detenida.")
        logger.info("Garantizando limpieza de caché al final de la ejecución.")
        cache_manager.clear_audio_cache()

if __name__ == '__main__':
    cache_manager.init_cache_dir()
    DibloApp().run()
